<footer>
    <p>&copy; <?php echo date( 'Y' ); ?> Mon Site - Tous droits réservés.</p>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
